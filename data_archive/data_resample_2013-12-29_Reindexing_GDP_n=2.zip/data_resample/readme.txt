This file contains results from a resampling run on Matt's laptop on 2013-12-29. The run took 1413 seconds.  There are only 2 resamples. 

* The biggest change is that the resampled indexed GDP data
is now being re-indexed to provide y_0 = 1 for every resample.
This is being done in the doResample function of the Econ-Growth-Resampling.R file.

Other features in the code for this run include:

These data were created by the console command

genAllResampleData(n=2)

Still saving resample models in lists to disk.

Still calculating alpha, beta, and gamma values for CES models based on delta and delta_1 parameters.

The CES algorithm is unchanged from October.  It looks like this:

a) Grid search in values of rho and rho1.  Gradient search (both PORT and L-BFGSB) is used to find the best values of lambda, gamma, delta, and delta_1 on all points of the rho, rho1 grid.  rho grid values are:  9, 2, 1, 0.43, 0.25, 0.1, -0.1, -0.5, -0.75, -0.9, -0.99.

b) Next, we start from the best grid search point and perform a gradient search will all variables in play.  Both PORT and L-BFGS-B algorithms are used for the gradient search.

c) Finally, we start from the fit to historical data and perform a gradient search from there.  Again, both PORT and L-BFGS-B algorithms are used for the gradient search.


--Matthew Kuperus Heun, 2013-12-29