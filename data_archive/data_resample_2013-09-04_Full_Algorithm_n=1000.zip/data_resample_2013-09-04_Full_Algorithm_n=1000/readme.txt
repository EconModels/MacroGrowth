This directory contains results from a mixture of:

(a) a resampling run on dahl on 2013-08-27. That run took 5 days to complete. But, I didn't have a data_failure directory, so the results from Iran weren't generated.  This was due to the fact that the CES without energy had failures but couldn't write the failure information to the data_failure directory.  Therefore, the CES (without energy), the CES models with energy (all nestings), and the LINEX models didn't work for Iran.

(b) a resampling run on Matt's computer on 2013-09-03 wherein I'm re-running all of the resample runs for Iran.  I'm using clobber=FALSE so that I keep all of the other data from the previous run on dahl.

For both of these runs, we're running the entire algorithm for all CES (with energy) resample runs. That is, we use gradient search from the the default start point, a grid search, and gradient search from the best of previous for both algorithms (PORT and L-BFGSB) for ALL of the data that we generate.

--Matthew Kuperus Heun, 2013-09-04