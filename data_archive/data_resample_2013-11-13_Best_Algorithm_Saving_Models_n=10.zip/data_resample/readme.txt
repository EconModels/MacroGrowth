This file contains results from a resampling run on Matt's MacBook Pro begun on  2013-11-13. The run took about an hour to complete.  There were only 10 resamples.

New features in the code before this run was made include:

1) Now saving resample models in lists to disk.
2) Now calculating alpha, beta, and gamma values for CES models based on delta and delta_1 parameters.

The CES algorithm is unchanged from October.  It looks like this:

1) Grid search in values of rho and rho1.  Gradient search (both PORT and L-BFGSB) is used to find the best values of lambda, gamma, delta, and delta_1 on all points of the rho, rho1 grid.  rho grid values are:  9, 2, 1, 0.43, 0.25, 0.1, -0.1, -0.5, -0.75, -0.9, -0.99.

2) Next, we start from the best grid search point and perform a gradient search will all variables in play.  Both PORT and L-BFGS-B algorithms are used for the gradient search.

3) Finally, we start from the fit to historical data and perform a gradient search from there.  Again, both PORT and L-BFGS-B algorithms are used for the gradient search.


--Matthew Kuperus Heun, 2013-11-14