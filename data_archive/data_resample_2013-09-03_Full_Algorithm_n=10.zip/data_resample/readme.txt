This file contains results from a resampling run on Matt's MacBook Pro. The run took 1.3 hours to complete. We ran the entire algorithm for all resample runs with n=10. That is, we used gradient search from the the default start point, a grid search, and gradient search from the best of previous for both algorithms (PORT and L-BFGSB) for ALL of the data that we generate.

This run is identical to the file named "data_resample_2013-08-27_Full_Algorithm_n=1000.zip", except that we are using n=10, whereas "data_resample_2013-08-27_Full_Algorithm_n=1000.zip" used n=1000.

--Matthew Kuperus Heun, 3 Sept 2013
