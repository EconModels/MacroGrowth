This file contains results from a resampling run on dahl begun on approximately 2013-09-16. The run took about 5 days to complete. 

We ran the entire algorithm for all CES resample runs. That is, we use gradient search from the the default start point, a grid search, and a gradient search from the historical coefficients. Finally, we did a gradient search from the best of previous. All were done for both algorithms (PORT and L-BFGSB) for ALL of the data that we generate.

--Matthew Kuperus Heun, 2013-09-23