These data were generated on 16 August July 2013. These runs used the new algorithm that tries the following:

* gradient search default starting point (sigma = 0.8, sigma_1 = 0.8), PORT and L-BFGS-B
* grid search, PORT and L-BFGS-B
* best point from the above, PORT and L-BFGS-B

The objective here was solve a problem from previous runs wherein waaay too many of the resample runs (and orig runs, for that matter) had sigma and sigma_1 values equal to the default start value.

We were mostly successful.  I have a few questions about the results, but they mostly look good.